Change Log — _Ray Tracing in One Weekend_
================================================================================

v1.54.0  (2018-08-26)
----------------------
  - The _Ray Tracing in One Weekend_ book series is now free!
  - First GitHub release of the book, bundled with source code.

